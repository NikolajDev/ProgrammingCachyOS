class Op:
    def __init__(self, op: str,
                 left: 'Expression',
                 right: 'Expression'):
        self.op = op
        self.left = left
        self.right = right


# number or variable or arithmetic operation
Expression = int | str | Op


DIGITS = "0123456789"


def to_str(num: int) -> str:
    assert num >= 0
    if num == 0:
        return "0"
    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


def draw_graphviz(expr: Expression, filename: str) -> None:
    stack = [(expr, "0")]
    next_id = 1
    with open(filename, "w") as f:
        f.write("digraph {")
        while len(stack) != 0:
            node, nid = stack.pop()
            f.write("n" + nid + " [label=\"")
            if isinstance(node, Op):
                f.write(node.op)
            elif isinstance(node, str):
                f.write(node)
            else:
                f.write(to_str(node))
            f.write("\"]\n")

            if isinstance(node, Op):
                lid = to_str(next_id)
                rid = to_str(next_id + 1)
                next_id += 2
                stack.append((node.left, lid))
                stack.append((node.right, rid))
                f.write("n" + nid + " -> n" + lid + "\n" +
                        "n" + nid + " -> n" + rid + "\n")
        f.write("}")


# try running:
# draw_graphviz(Op('*', Op('+', 3, 'x'), 4), "expr.dot")

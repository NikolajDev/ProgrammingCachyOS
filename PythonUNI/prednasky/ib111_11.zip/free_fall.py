import sys

GRAVITY = 9.81

# if you want to avoid calling .index on a ten-element list,
# you can use a dict instead

DIGITS = list("0123456789")


def to_int(digits: str) -> int | None:
    if digits == "":
        return None
    result = 0
    for digit in digits:
        if digit not in DIGITS:
            return None
        result = result * 10 + DIGITS.index(digit)
    return result


def to_str(num: int) -> str:
    # this only works for non-negative numbers
    # (try extending it!)
    if num == 0:
        return "0"
    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


def height(time: int) -> int:
    return round(GRAVITY * time ** 2 / 2)


def main() -> None:
    sys.stdout.write("Zadej dobu v sekundách: ")
    sys.stdout.flush()
    seconds = to_int(sys.stdin.readline().rstrip())
    if seconds is None:
        sys.stderr.write("Špatný formát vstupu.\n")
    else:
        sys.stdout.write("Výška v metrech: " + to_str(height(seconds)) + "\n")


if __name__ == '__main__':
    main()

SINGLE_CHAR_TOKENS = ["(", ")", "+", "*"]
DIGITS = list("0123456789")
END = ""


def to_tokens(expr: str) -> list[str]:
    # precondition: expr is a valid expression
    tokens = []
    pos = 0
    token = "0"  # dummy, something different from END
    while token != END:
        token, pos = next_token(expr, pos)
        tokens.append(token)
    return tokens


def next_token(expr: str, pos: int) -> tuple[str, int]:
    token = ""
    # ignore spaces
    while pos < len(expr) and expr[pos] == " ":
        pos += 1

    if pos == len(expr):
        return END, pos

    if expr[pos] in SINGLE_CHAR_TOKENS:
        return expr[pos], pos + 1

    if expr[pos].isdecimal():
        # reading a number
        while pos < len(expr) and expr[pos].isdecimal():
            token += expr[pos]
            pos += 1
        return token, pos

    if expr[pos].isalpha():
        # reading a variable name
        while pos < len(expr) and (
                expr[pos].isdecimal() or expr[pos].isalpha()):
            token += expr[pos]
            pos += 1
        return token, pos

    assert False

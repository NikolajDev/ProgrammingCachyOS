# change this if your platform doesn't have a /tmp directory
filename = "/tmp/my_file"

with open(filename, "w") as my_file:
    my_file.write("’Twas brillig, and the slithy toves\n")
    my_file.write("Did gyre and gimble in the wabe;\n")
    my_file.write("All mimsy were the borogoves,\n")
    my_file.write("And the mome raths outgrabe.\n")

with open(filename, "r") as my_file:
    print(my_file.read(5))
    print(my_file.readline())
    print(my_file.readline())

with open(filename, "r") as my_file:
    lines = my_file.readlines()

print(lines)

with open(filename, "r") as my_file:
    for line in my_file:
        print(len(line))

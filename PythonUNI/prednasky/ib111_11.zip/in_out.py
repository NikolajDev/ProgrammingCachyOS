import sys

sys.stdout.write("What is your name? ")
sys.stdout.flush()
name = sys.stdin.readline().rstrip()
if name == "":
    sys.stderr.write("Error: No name given.\n")
else:
    sys.stdout.write("Hello, " + name + ", nice to meet you.\n")

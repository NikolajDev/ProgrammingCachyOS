SINGLE_CHAR_TOKENS = ["(", ")", "+", "*"]
DIGITS = list("0123456789")
END = ""


def to_tokens(expr: str) -> list[str] | None:
    # no precondition about expr, can contain invalid symbols
    # (in that case, we return None)
    tokens = []
    pos = 0
    token = None  # dummy, something different from END
    while token != END:
        token, pos = next_token(expr, pos)
        if token is None:
            return None
        tokens.append(token)
    return tokens


def next_token(expr: str, pos: int) -> tuple[str | None, int]:
    token = ""
    # ignore spaces
    while pos < len(expr) and expr[pos] == " ":
        pos += 1

    if pos == len(expr):
        return END, pos

    if expr[pos] in SINGLE_CHAR_TOKENS:
        return expr[pos], pos + 1

    if expr[pos].isdecimal():
        # reading a number
        while pos < len(expr) and expr[pos].isdecimal():
            token += expr[pos]
            pos += 1
        return token, pos

    if expr[pos].isalpha():
        # reading a variable name
        while pos < len(expr) and (
                expr[pos].isdecimal() or expr[pos].isalpha()):
            token += expr[pos]
            pos += 1
        return token, pos

    return None, pos

noel1 = "noël"
print(noel1, len(noel1))
noel2 = "noe\u0308l"
print(noel2, len(noel2))

class Parser:
    def __init__(self, expr: str):
        self.tokens = to_tokens(expr)
        self.index = 0

    def peek(self) -> str:
        return self.tokens[self.index]

    def consume(self) -> None:
        self.index += 1

    def next(self) -> str:
        token = self.peek()
        self.consume()
        return token

    def expression(self) -> 'Expression':
        token = self.next()

        if token == '(':
            left = self.expression()
            op = self.next()
            right = self.expression()
            self.consume()  # ')'
            return Op(op, left, right)

        if token.isdecimal():
            return to_int(token)

        # it has to be a variable name
        return token


def parse_expression(expr: str) -> 'Expression':
    return Parser(expr).expression()


def to_int(digits: str) -> int:
    result = 0
    for digit in digits:
        result = result * 10 + DIGITS.index(digit)
    return result


# --- from lex1.py ---

SINGLE_CHAR_TOKENS = ["(", ")", "+", "*"]
DIGITS = list("0123456789")
END = ""


def to_tokens(expr: str) -> list[str]:
    # precondition: expr is a valid expression
    tokens = []
    pos = 0
    token = "0"  # dummy, something different from END
    while token != END:
        token, pos = next_token(expr, pos)
        tokens.append(token)
    return tokens


def next_token(expr: str, pos: int) -> tuple[str, int]:
    token = ""
    # ignore spaces
    while pos < len(expr) and expr[pos] == " ":
        pos += 1

    if pos == len(expr):
        return END, pos

    if expr[pos] in SINGLE_CHAR_TOKENS:
        return expr[pos], pos + 1

    if expr[pos].isdecimal():
        # reading a number
        while pos < len(expr) and expr[pos].isdecimal():
            token += expr[pos]
            pos += 1
        return token, pos

    if expr[pos].isalpha():
        # reading a variable name
        while pos < len(expr) and (
                expr[pos].isdecimal() or expr[pos].isalpha()):
            token += expr[pos]
            pos += 1
        return token, pos

    assert False


# --- from expr.py ---

class Op:
    def __init__(self, op: str,
                 left: 'Expression',
                 right: 'Expression'):
        self.op = op
        self.left = left
        self.right = right


# number or variable or arithmetic operation
Expression = int | str | Op


def to_str(num: int) -> str:
    assert num >= 0
    if num == 0:
        return "0"
    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


def draw_graphviz(expr: Expression, filename: str) -> None:
    stack = [(expr, "0")]
    next_id = 1
    with open(filename, "w") as f:
        f.write("digraph {")
        while len(stack) != 0:
            node, nid = stack.pop()
            f.write("n" + nid + " [label=\"")
            if isinstance(node, Op):
                f.write(node.op)
            elif isinstance(node, str):
                f.write(node)
            else:
                f.write(to_str(node))
            f.write("\"]\n")

            if isinstance(node, Op):
                lid = to_str(next_id)
                rid = to_str(next_id + 1)
                next_id += 2
                stack.append((node.left, lid))
                stack.append((node.right, rid))
                f.write("n" + nid + " -> n" + lid + "\n" +
                        "n" + nid + " -> n" + rid + "\n")
        f.write("}")

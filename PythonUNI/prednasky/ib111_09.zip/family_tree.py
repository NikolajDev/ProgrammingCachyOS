class Person:
    def __init__(self, name: str):
        self.name = name
        self.parent: Person | None = None
        self.children: list[Person] = []

    def add_child(self, child: 'Person') -> None:
        self.children.append(child)
        child.parent = self


def siblings(person_a: Person,
             person_b: Person) -> bool:
    return person_a.parent is not None \
        and person_a.parent == person_b.parent


def oldest_ancestor1(person: Person) -> Person:
    while person.parent is not None:
        person = person.parent
    return person


def oldest_ancestor2(person: Person) -> Person:
    if person.parent is None:
        return person
    return oldest_ancestor2(person.parent)


def count_offspring(person: Person) -> int:
    count = 0
    for child in person.children:
        count += 1 + count_offspring(child)
    return count


def draw_family_tree(person: Person) -> None:
    draw_family_tree_aux(person, 0)


def draw_family_tree_aux(person: Person,
                         indent: int) -> None:
    print_with_indent(indent, person.name)
    for child in person.children:
        draw_family_tree_aux(child, indent + 4)


def print_with_indent(indent: int, msg: str) -> None:
    for _ in range(indent):
        print(" ", end="")
    print(msg)


# The Simpsons
abe = Person("Abraham Simpson")
homer = Person("Homer Simpson")
abe.add_child(homer)
homer.add_child(Person("Bart Simpson"))
homer.add_child(Person("Lisa Simpson"))
homer.add_child(Person("Maggie Simpson"))
bart = homer.children[0]
lisa = homer.children[1]
maggie = homer.children[2]

# The British Royal Family
queen = Person("Queen Elisabeth II")
charles = Person("King Charles III")
anne = Person("Princess Anne")
andrew = Person("Prince Andrew")
edward = Person("Prince Edward")
william = Person("Prince William")
harry = Person("Prince Harry")
george = Person("Prince George")
charlotte = Person("Princess Charlotte")
louis = Person("Prince Louis")
archie = Person("Prince Archie")
lilibet = Person("Princess Lilibet")
beatrice = Person("Princess Beatrice")
eugenie = Person("Princess Eugenie")
sienna = Person("Sienna Mapelli Mozzi")
august = Person("August Brooksbank")
ernest = Person("Ernest Brooksbank")
louise = Person("Lady Louise Mountbatten-Windsor")
james = Person("James Mountbatten-Windsor")
peter = Person("Peter Phillips")
savannah = Person("Savannah Phillips")
isla = Person("Isla Phillips")
zara = Person("Zara Tindall")
mia = Person("Mia Tindall")
lena = Person("Lena Tindall")
lucas = Person("Lucas Tindall")
queen.add_child(charles)
queen.add_child(anne)
queen.add_child(andrew)
queen.add_child(edward)
charles.add_child(william)
charles.add_child(harry)
william.add_child(george)
william.add_child(charlotte)
william.add_child(louis)
harry.add_child(archie)
harry.add_child(lilibet)
andrew.add_child(beatrice)
andrew.add_child(eugenie)
beatrice.add_child(sienna)
eugenie.add_child(august)
eugenie.add_child(ernest)
edward.add_child(louise)
edward.add_child(james)
anne.add_child(peter)
anne.add_child(zara)
peter.add_child(savannah)
peter.add_child(isla)
zara.add_child(mia)
zara.add_child(lena)
zara.add_child(lucas)

# ----------

print(bart.name)
assert bart.parent is not None
print(bart.parent.name)
print(siblings(bart, lisa))
print(siblings(homer, bart))
print(siblings(maggie, abe))

root = oldest_ancestor1(charlotte)
print(root.name)

print(oldest_ancestor2(maggie).name)

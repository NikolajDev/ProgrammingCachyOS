from turtle import forward, left


def triangle(length: int) -> None:
    for _ in range(3):
        forward(length)
        left(120)


def sierpinski(steps: int, length: int) -> None:
    if steps == 1:
        triangle(length)
    else:
        for _ in range(3):
            sierpinski(steps - 1, length)
            forward(2 ** (steps - 1) * length)
            left(120)


def better_sierpinski(steps: int, length: int) -> None:
    if steps > 0:
        for _ in range(3):
            sierpinski(steps - 1, length)
            forward(2 ** (steps - 1) * length)
            left(120)

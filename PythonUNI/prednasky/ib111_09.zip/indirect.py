# Note: This is NOT a good way of computing the even / odd predicates.
# This is just a demonstration of indirect recursion.

def even(num: int) -> bool:
    if num == 0:
        return True
    return odd(num - 1)


def odd(num: int) -> bool:
    if num == 0:
        return False
    return even(num - 1)

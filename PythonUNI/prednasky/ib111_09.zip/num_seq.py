def sequence(num: int) -> None:
    if num > 1:
        sequence(num - 1)
    print(num)


def seq_pure1(num: int) -> list[int]:
    if num == 0:
        return []
    return seq_pure1(num - 1) + [num]


def seq_pure2(num: int) -> list[int]:
    if num == 0:
        return []
    result = seq_pure2(num - 1)
    result.append(num)
    return result

def wrong1(num: int) -> int:
    return num * wrong1(num - 1)


def wrong2(num: int) -> int:
    if num <= 1:
        return num

    return 1 + wrong2(num)


def wrong3(num: int) -> int:
    if num > 1000:
        return 1000

    return 1 + wrong3(num - 1)


def wrong4(num: float) -> float:
    if num < 0:
        return 0

    return 1 + wrong4(num / 2)

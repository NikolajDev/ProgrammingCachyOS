def hanoi(num: int, start: str, end: str, aux: str) \
        -> None:
    if num == 1:
        print(start, "->", end)
    else:
        hanoi(num - 1, start, aux, end)
        print(start, "->", end)
        hanoi(num - 1, aux, end, start)


def hanoi_better(num: int, start: str,
                 end: str, aux: str) -> None:
    if num > 0:
        hanoi_better(num - 1, start, aux, end)
        print(start, "->", end)
        hanoi_better(num - 1, aux, end, start)


State = dict[str, list[int]]


def move(source: str, destination: str,
         state: State) -> None:
    print("Move", source, "->", destination)
    state[destination].append(state[source].pop())
    print(state)


def hanoi_solve(num: int, start: str,
                end: str, aux: str,
                state: State) -> None:
    if num > 0:
        hanoi_solve(num - 1, start, aux, end, state)
        move(start, end, state)
        hanoi_solve(num - 1, aux, end, start, state)


def hanoi_main(num: int) -> None:
    state: State = {"A": list(range(num, 0, -1)), "B": [], "C": []}
    print(state)
    hanoi_solve(num, "A", "C", "B", state)

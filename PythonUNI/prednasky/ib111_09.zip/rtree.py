from turtle import forward, left, right, backward


def tree(length: float) -> None:
    forward(length)
    if length > 10:
        left(45)
        tree(0.6 * length)
        right(90)
        tree(0.6 * length)
        left(45)
    backward(length)

def mystery_rec(num: int, result: list[int]) -> None:
    result.append(num)
    if num > 1:
        mystery_rec(num - 1, result)
    result.append(-num)


def mystery(num: int) -> list[int]:
    result: list[int] = []
    mystery_rec(num, result)
    return result

NestedList = list['int | NestedList']


def nested_list_sum1(nl: NestedList) -> int:
    total = 0
    for elem in nl:
        if isinstance(elem, list):
            total += nested_list_sum1(elem)
        else:
            # mypy knows the type of elem is int here
            total += elem

    return total


def nested_list_sum2(value: int | NestedList) -> int:
    if isinstance(value, int):
        return value

    # mypy knows the type of value is NestedList here
    total = 0
    for item in value:
        total += nested_list_sum2(item)

    return total


def nested_list_sum(nl: NestedList) -> int:
    return nested_list_sum2(nl)

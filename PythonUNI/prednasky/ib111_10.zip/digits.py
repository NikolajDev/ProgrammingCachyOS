def digit_sum_numbers(total: int) -> list[int]:
    """Assumes that total > 0.
    Returns the list of all numbers whose decimal notation
    - contains no zeroes, and
    - sums to given total."""
    return dsn_rec(total, [], 0)


def dsn_rec(remaining: int, result: list[int],
            current: int) -> list[int]:
    if remaining == 0:
        result.append(current)
    elif remaining > 0:
        for digit in range(1, 10):
            dsn_rec(remaining - digit, result,
                    current * 10 + digit)
    # else: nothing -- solution missed

    return result

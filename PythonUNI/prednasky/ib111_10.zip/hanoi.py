Moves = list[tuple[str, str]]


def hanoi(num: int, start: str,
          end: str, aux: str) -> Moves:
    if num == 0:
        return []
    return (
        hanoi(num - 1, start, aux, end) +
        [(start, end)] +
        hanoi(num - 1, aux, end, start)
    )


def hanoi_better(num: int, start: str,
                 end: str, aux: str) -> Moves:
    return hanoi_aux(num, start, end, aux, [])


def hanoi_aux(num: int, start: str, end: str,
              aux: str, moves: Moves) -> Moves:
    if num > 0:
        hanoi_aux(num - 1, start, aux, end, moves)
        moves.append((start, end))
        hanoi_aux(num - 1, aux, end, start, moves)
    return moves

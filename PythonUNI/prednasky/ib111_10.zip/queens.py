def queens(size: int) -> list[int] | None:
    return queens_recursive([], size)


def queens_recursive(state: list[int], size: int) \
        -> list[int] | None:
    if len(state) == size:
        # solution!
        return state

    for row in range(size):
        if queen_check(state, row):
            state.append(row)
            result = queens_recursive(state, size)
            if result is not None:
                return result
            state.pop()

    return None


def queen_check(state: list[int], new_row: int) -> bool:
    new_col = len(state)
    for col, row in enumerate(state):
        if row == new_row or \
           abs(row - new_row) == abs(col - new_col):
            return False
    return True


def draw_chessboard(state: list[int], size: int) -> None:
    for row in range(size - 1, -1, -1):
        draw_line(size)
        print("|", end="")
        for col in range(size):
            print(" Q " if col < len(state) and state[col] == row
                  else "   ", end="|")
        print()

    draw_line(size)


def draw_line(size: int) -> None:
    for _ in range(size):
        print("+---", end="")
    print("+")

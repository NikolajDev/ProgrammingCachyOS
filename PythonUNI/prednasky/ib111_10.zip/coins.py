def min_coins(amount: int, coins: list[int]) \
        -> int | None:
    return min_coins_rec(amount, coins, 0, None)


def min_coins_rec(amount: int, coins: list[int],
                  count: int, best: int | None) \
        -> int | None:
    if count == best or amount == 0:
        return count

    for coin in coins:
        if amount >= coin:
            best = min_coins_rec(amount - coin, coins,
                                 count + 1, best)

    return best

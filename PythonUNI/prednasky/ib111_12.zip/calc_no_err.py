import sys


# --- Abstract Syntax Tree ---

# This class represents operations of arbitrary arity
# (i.e. both unary and binary).
class Op:
    def __init__(self, op: str,
                 operands: list['Expression']):
        self.op = op
        self.operands = operands


# An expression can be either an integer or a (unary or binary) operation.
Expression = int | Op


# --- Expression Evaluation ---

def eval_expr(expr: Expression) -> int:
    if isinstance(expr, int):
        return expr

    # Op
    ops = [eval_expr(op) for op in expr.operands]

    if expr.op == '+u':
        return ops[0]

    if expr.op == '-u':
        return -ops[0]

    if expr.op == '+':
        return ops[0] + ops[1]

    if expr.op == '-':
        return ops[0] - ops[1]

    if expr.op == '*':
        return ops[0] * ops[1]

    if expr.op == '/':
        # what if ops[1] is zero?
        return ops[0] // ops[1]

    assert False  # unreachable


# --- Parser ---

# Note: We use strings to represent tokens.
# There are better options, but for the purpose of this simple example,
# strings are enough.

SINGLE_CHAR_TOKENS = {'+', '-', '*', '/', '(', ')'}
END = '\n'

# Operators, ordered by their precedence level, with corresponding arity.
# All binary operators are left-associative here.
# Unary ‹+› and ‹-› are treated specially (see below) and after parsing,
# they are represented by the pseudo-operators ‹+u› and ‹-u›.

OPS_BY_PREC = [
    (2, {'+', '-'}),  # binary ‹+› and ‹-›
    (2, {'*', '/'}),
    (1, {'+', '-'}),  # unary ‹+› and ‹-›, special-cased
]


class Parser:
    def __init__(self, line: str):
        self.tokens = tokenize(line)
        self.index = 0

    def peek(self) -> str:
        return self.tokens[self.index]

    def consume(self) -> None:
        self.index += 1

    def next(self) -> str:
        token = self.peek()
        self.consume()
        return token

    def accept(self, token: str) -> bool:
        if self.peek() != token:
            return False
        self.consume()
        return True

    def expression(self, level: int) -> Expression:
        if level == len(OPS_BY_PREC):
            return self.simple_expr()

        arity, ops = OPS_BY_PREC[level]

        if arity == 1:
            if self.peek() not in ops:
                return self.expression(level + 1)

            op = self.next()
            if op in ['+', '-']:  # special case for unary ‹+› and ‹-›
                op += 'u'
            return Op(op, [self.expression(level)])

        # binary ops
        current = self.expression(level + 1)
        while self.peek() in ops:
            op = self.next()
            right = self.expression(level + 1)
            current = Op(op, [current, right])

        return current

    def simple_expr(self) -> Expression:
        if self.accept('('):
            expr = self.expression(0)
            self.consume()  # ')'
            return expr

        return to_int(self.next())


# --- Lexer ---

def tokenize(line: str) -> list[str]:
    tokens = []
    pos = 0
    token = ''

    while token != END:
        token, pos = next_token(line, pos)
        tokens.append(token)

    return tokens


def next_token(line: str, pos: int) -> tuple[str, int]:
    # we assume that line ends with '\n'; this simplifies the cycles
    token = ""

    # ignore spaces
    while line[pos] == ' ':
        pos += 1

    if line[pos] == END or line[pos] in SINGLE_CHAR_TOKENS:
        return line[pos], pos + 1

    if line[pos].isdecimal():
        # reading a number
        while line[pos].isdecimal():
            token += line[pos]
            pos += 1
        return token, pos

    assert False  # unreachable


# --- AST Graph ---

class ASTGraph:
    def __init__(self, expr: Expression) -> None:
        self.nodes: list[str] = []
        self.edges: list[tuple[int, int]] = []
        self.add_expr(expr)

    def add_node(self, label: str) -> int:
        self.nodes.append(label)
        return len(self.nodes) - 1

    def add_edge(self, src: int, dst: int) -> None:
        self.edges.append((src, dst))

    def add_expr(self, expr: Expression) -> int:
        if isinstance(expr, int):
            return self.add_node(to_str(expr))

        this = self.add_node(expr.op)
        for operand in expr.operands:
            self.add_edge(this, self.add_expr(operand))

        return this

    def draw(self, filename: str) -> None:
        with open(filename, 'w') as dot_file:
            dot_file.write("digraph {\n")

            for i, node in enumerate(self.nodes):
                dot_file.write('n' + to_str(i) + ' [label="' + node + '"]\n')

            for src, dst in self.edges:
                dot_file.write('n' + to_str(src) +
                               ' -> n' + to_str(dst) + '\n')

            dot_file.write("}\n")


# --- Conversion Functions ---

DIGITS = list("0123456789")


def to_int(digits: str) -> int:
    result = 0
    for digit in digits:
        result = result * 10 + DIGITS.index(digit)
    return result


def to_str(num: int) -> str:
    if num == 0:
        return "0"
    if num < 0:
        return '-' + to_str(-num)

    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


# --- Main Functions ---

def draw(expr: Expression, filename: str) -> None:
    ASTGraph(expr).draw(filename)


# Note: The function ‹parse_expr› is pure.

def parse_expr(line: str) -> Expression:
    return Parser(line).expression(0)


def main() -> None:
    sys.stdout.write("Calculator 2024 (without error handling!)\n"
                     "(enter empty line to quit)\n")
    while True:
        sys.stdout.write(">>> ")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line.rstrip() == "":
            break
        sys.stdout.write("Result: " + to_str(eval_expr(parse_expr(line)))
                         + "\n")

    sys.stdout.write("Goodbye!\n")


if __name__ == '__main__':
    main()
    # also try "0 - 9 + 9 * 9"
    # expr = parse_expr("17 + 42 * 9 / 1 - 13 * (3 + 7)")
    # draw(expr, "ast.dot")

def main():
    n = 5
    print(fact_rec(n))
    print(fact_iter(n))


def fact_rec(n):
    if n == 0:
        return 1

    return n * fact_rec(n - 1)


def fact_iter(n):
    result = 1
    while n > 0:
        result = result * n
        n = n - 1

    return result

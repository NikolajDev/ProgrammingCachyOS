import sys


class Error:
    def __init__(self, msg: str):
        self.msg = msg


# --- Abstract Syntax Tree ---

# This class represents operations of arbitrary arity
# (i.e. both unary and binary).
class Op:
    def __init__(self, op: str,
                 operands: list['Expression']):
        self.op = op
        self.operands = operands


# An expression can be either an integer or a (unary or binary) operation.
Expression = int | str | Op


# --- Expression Evaluation ---

def eval_expr(expr: Expression,
              env: dict[str, int]) -> int | Error:
    if isinstance(expr, int):
        return expr

    if isinstance(expr, str):
        if expr not in env:
            return Error("Variable ‹" + expr +
                         "› has no value.")
        return env[expr]

    # Op
    ops = []
    for op in expr.operands:
        value = eval_expr(op, env)
        if isinstance(value, Error):
            return value
        ops.append(value)

    if expr.op == '+u':
        return ops[0]

    if expr.op == '-u':
        return -ops[0]

    if expr.op == '+':
        return ops[0] + ops[1]

    if expr.op == '-':
        return ops[0] - ops[1]

    if expr.op == '*':
        return ops[0] * ops[1]

    if expr.op == '/':
        if ops[1] == 0:
            return Error("Division by zero.")

        return ops[0] // ops[1]

    assert False  # unreachable


# --- Parser ---

# Note: We use strings to represent tokens.
# There are better options, but for the purpose of this simple example,
# strings are enough.

SINGLE_CHAR_TOKENS = {'+', '-', '*', '/', '(', ')'}
END = '\n'

# Operators, ordered by their precedence level, with corresponding arity.
# All binary operators are left-associative here.
# Unary ‹+› and ‹-› are treated specially (see below) and after parsing,
# they are represented by the pseudo-operators ‹+u› and ‹-u›.

OPS_BY_PREC = [
    (2, {'+', '-'}),  # binary ‹+› and ‹-›
    (2, {'*', '/'}),
    (1, {'+', '-'}),  # unary ‹+› and ‹-›, special-cased
]


class Parser:
    def __init__(self, line: str):
        tokens = tokenize(line)
        if isinstance(tokens, Error):
            self.error: None | Error = tokens
            self.tokens = [END]
        else:
            self.error = None
            self.tokens = tokens
        self.index = 0

    def set_error(self, msg: str) -> None:
        self.error = Error(msg)

    def set_error_expecting(self, expected: str) -> None:
        self.set_error("Expected " + expected +
                       ", found " + token_repr(self.peek()) + ".")

    def peek(self) -> str:
        return self.tokens[self.index]

    def consume(self) -> None:
        self.index += 1

    def next(self) -> str:
        token = self.peek()
        self.consume()
        return token

    def accept(self, token: str) -> bool:
        if self.peek() != token:
            return False
        self.consume()
        return True

    def expect(self, token: str) -> bool:
        if self.accept(token):
            return True
        self.set_error_expecting(token_repr(token))
        return False

    def try_ident(self) -> str | None:
        if is_ident(self.peek()):
            return self.next()
        return None

    def parse(self) -> Expression | Error:
        if self.error is not None:
            return self.error  # Propagate error from ‹tokenize›.

        expr = self.expression(0)
        if expr is None or not self.expect(END):
            assert self.error is not None
            return self.error

        return expr

    def expression(self, level: int) -> Expression | None:
        if level == len(OPS_BY_PREC):
            return self.simple_expr()

        arity, ops = OPS_BY_PREC[level]

        if arity == 1:
            if self.peek() not in ops:
                return self.expression(level + 1)

            op = self.next()
            if op in ['+', '-']:  # special case for unary ‹+› and ‹-›
                op += 'u'
            expr = self.expression(level)
            if expr is None:
                return None

            return Op(op, [expr])

        # binary ops
        current = self.expression(level + 1)
        if current is None:
            return None

        while self.peek() in ops:
            op = self.next()
            right = self.expression(level + 1)
            if right is None:
                return None

            current = Op(op, [current, right])

        return current

    def simple_expr(self) -> Expression | None:
        if self.accept('('):
            expr = self.expression(0)
            if expr is None or not self.expect(')'):
                return None

            return expr

        var = self.try_ident()
        if var is not None:
            return var

        num = to_int(self.peek())
        if num is not None:
            self.consume()
            return num

        self.set_error_expecting("expression")
        return None


# --- Lexer ---

def tokenize(line: str) -> list[str] | Error:
    tokens = []
    pos = 0
    token = ''

    while token != END:
        nt = next_token(line, pos)
        if isinstance(nt, Error):
            return nt
        token, pos = nt
        tokens.append(token)

    return tokens


def next_token(line: str, pos: int) -> tuple[str, int] | Error:
    # we assume that line ends with '\n'; this simplifies the cycles
    token = ""

    # ignore spaces
    while line[pos] == ' ':
        pos += 1

    if line[pos] == END or line[pos] in SINGLE_CHAR_TOKENS:
        return line[pos], pos + 1

    if line[pos].isdecimal():
        # reading a number
        while line[pos].isdecimal():
            token += line[pos]
            pos += 1
        return token, pos

    if is_ident_start(line[pos]):
        while is_ident_inside(line[pos]):
            token += line[pos]
            pos += 1
        return token, pos

    return Error("Invalid character ‹" + line[pos] + "› in column "
                 + to_str(pos + 1) + ".")


def token_repr(token: str) -> str:
    return "end of line" if token == END else "‹" + token + "›"


def is_ident(token: str) -> bool:
    return is_ident_start(token[0])


def is_ident_start(char: str) -> bool:
    return char.isalpha() or char == '_'


def is_ident_inside(char: str) -> bool:
    return is_ident_start(char) or char.isdecimal()


# --- AST Graph ---

class ASTGraph:
    def __init__(self, expr: Expression) -> None:
        self.nodes: list[str] = []
        self.edges: list[tuple[int, int]] = []
        self.add_expr(expr)

    def add_node(self, label: str) -> int:
        self.nodes.append(label)
        return len(self.nodes) - 1

    def add_edge(self, src: int, dst: int) -> None:
        self.edges.append((src, dst))

    def add_expr(self, expr: Expression) -> int:
        if isinstance(expr, int):
            return self.add_node(to_str(expr))

        if isinstance(expr, str):
            return self.add_node(expr)

        this = self.add_node(expr.op)
        for operand in expr.operands:
            self.add_edge(this, self.add_expr(operand))

        return this

    def draw(self, filename: str) -> None:
        with open(filename, 'w') as dot_file:
            dot_file.write("digraph {\n")

            for i, node in enumerate(self.nodes):
                dot_file.write('n' + to_str(i) + ' [label="' + node + '"]\n')

            for src, dst in self.edges:
                dot_file.write('n' + to_str(src) +
                               ' -> n' + to_str(dst) + '\n')

            dot_file.write("}\n")


# --- Conversion Functions ---

DIGITS = list("0123456789")


def to_int(digits: str) -> int | None:
    result = 0
    for digit in digits:
        if digit not in DIGITS:
            return None
        result = result * 10 + DIGITS.index(digit)
    return result


def to_str(num: int) -> str:
    if num == 0:
        return "0"
    if num < 0:
        return '-' + to_str(-num)

    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


# --- Main Functions ---

def draw(expr: Expression, filename: str) -> None:
    ASTGraph(expr).draw(filename)


# Note: The function ‹parse_expr› is pure.

def parse_expr(line: str) -> Expression | Error:
    return Parser(line).parse()


def print_error(kind: str, err: Error) -> None:
    sys.stderr.write(kind + " error: " + err.msg + "\n")


def main() -> None:
    sys.stdout.write("Calculator 2024 (now with variables!)\n"
                     "(enter empty line to quit)\n")
    env: dict[str, int] = {}
    while True:
        var = None
        sys.stdout.write(">>> ")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line.rstrip() == "":
            break

        parts = line.split('=')
        if len(parts) > 2:
            print_error("Syntax", Error("Too many ‹=›s on line."))
            continue

        if len(parts) == 2:
            # Note: ‹parse_expr› expects an end-of-line character.
            lhs = parse_expr(parts[0] + '\n')
            if not isinstance(lhs, str):
                print_error(
                    "Syntax",
                    Error("Expected variable on left-hand side of ‹=›.")
                )
                continue
            var = lhs

        expr = parse_expr(parts[-1])
        if isinstance(expr, Error):
            print_error("Syntax", expr)
            continue

        value = eval_expr(expr, env)
        if isinstance(value, Error):
            print_error("Runtime", value)
        elif var is None:
            sys.stdout.write("Result: " + to_str(value) + "\n")
        else:
            env[var] = value

    sys.stdout.write("Goodbye!\n")


if __name__ == '__main__':
    main()
    # expr = parse_expr("a + b + c + d * 0")
    # assert not isinstance(expr, Error)
    # draw(expr, "ast.dot")

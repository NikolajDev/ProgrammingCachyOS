# We can now use if and while statements!

num = 5
fact = 1
while num > 0:
    fact = fact * num
    num = num - 1

answer = 0
if fact == 120:
    answer = 42
    num = 0


# elifs also work (they are internally represented as else / if)

if answer < 10:
    x = 1
elif answer < 20:
    x = 2
elif answer < 40:
    x = 3
else:
    x = 4

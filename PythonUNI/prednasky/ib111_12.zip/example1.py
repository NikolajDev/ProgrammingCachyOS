# Try to give this file as an argument to asgn_prog1.py.
a = 9
b = 0 - a + a * 9 - 7
c = (0 - b + b) * 9 + -7
a = a + b + c + 100 * -2

def main():
    fractal(5)


def fractal(n):
    if n == 0:
        print(m, 0)
        return

    print(0, n)
    fractal(n - 1)
    print(1, n)
    fractal(n - 1)
    print(2, n)

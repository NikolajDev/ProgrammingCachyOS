# The relational operators in our simple programming language return 0 or 1.
answer = 42
true = answer == 42

# Note that 'and' and 'or' are shortcutting, just like in Python
# (and many other languages).

divisor = 0
this_is_ok = divisor != 0 and 10 / divisor > 3

this_is_ok = divisor == 0 or 10 / divisor > 3

# this is an error:
# not_ok = 10 / divisor > 3 and divisor != 0

def pow(base, exp):
    result = 1
    while exp > 0:
        exp = exp - 1
        result = result * base
    return result


def main():
    return pow(2, 2 * 10)

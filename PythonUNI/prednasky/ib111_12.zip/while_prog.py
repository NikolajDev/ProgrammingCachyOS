import sys


class Error:
    def __init__(self, msg: str):
        self.msg = msg
        # The line_no attribute for syntax errors is set by the parser.
        # We do not track the line numbers of statements in the interpreter,
        # and thus runtime errors always have line_no = 0.
        self.line_no = 0


# --- Abstract Syntax Tree ---

# This class represents operations of arbitrary arity
# (i.e. both unary and binary).
class Op:
    def __init__(self, op: str, operands: list['Expression']):
        self.op = op
        self.operands = operands


# An expression can be either an integer or a (unary or binary) operation.
Expression = int | str | Op


# An assignment is of the form ‹var = expression›.
class Assignment:
    def __init__(self, var: str, expr: Expression):
        self.var = var
        self.expr = expr


# A while statement has a condition and a body (a block of statements).
class While:
    def __init__(self, cond: Expression,
                 body: 'Block'):
        self.cond = cond
        self.body = body


# An if statement's structure is similar to that of a while statement,
# but it has an optional else branch.
# The parser actually allows for if ... elif ... else statements,
# but for simplicity, we represent them as if/else statements in the AST.
class If:
    def __init__(self, cond: Expression,
                 main_body: 'Block'):
        self.cond = cond
        self.main_body = main_body
        self.else_body: Block | None = None


# A statement is either an assignment, an if or while compound statement.
Statement = Assignment | If | While

Block = list[Statement]

# A program of our language is simply a block of statements.
Program = Block


# --- Interpreter ---

class Interpreter:
    def __init__(self, program: Program):
        self.program = program
        self.env: dict[str, int] = {}

    def run(self) -> dict[str, int] | Error:
        err = self.exec_block(self.program)
        if isinstance(err, Error):
            return err

        return self.env

    def exec_block(self, block: Block) \
            -> None | Error:
        for statement in block:
            err = self.execute(statement)
            if isinstance(err, Error):
                return err

        return None

    def execute(self, statement: Statement) \
            -> None | Error:
        if isinstance(statement, If):
            return self.exec_if(statement)

        if isinstance(statement, While):
            return self.exec_while(statement)

        # Assignment
        value = self.eval(statement.expr)
        if isinstance(value, Error):
            return value

        self.env[statement.var] = value
        return None

    def exec_if(self, if_stmt: If) -> None | Error:
        cond = self.eval(if_stmt.cond)
        if isinstance(cond, Error):
            return cond

        if cond != 0:
            return self.exec_block(if_stmt.main_body)

        if if_stmt.else_body is not None:
            return self.exec_block(if_stmt.else_body)

        return None

    def exec_while(self, while_stmt: While) \
            -> None | Error:
        while True:
            cond = self.eval(while_stmt.cond)
            if isinstance(cond, Error):
                return cond

            if cond == 0:
                return None

            block = self.exec_block(while_stmt.body)
            if isinstance(block, Error):
                return block

    def eval(self, expr: Expression) -> int | Error:
        if isinstance(expr, int):
            return expr

        if isinstance(expr, str):
            if expr not in self.env:
                return Error("Variable ‹" + expr + "› has no value.")
            return self.env[expr]

        # Op
        if expr.op in ['and', 'or']:
            left = self.eval(expr.operands[0])
            if shortcut(left, expr.op):
                return left
            return self.eval(expr.operands[1])

        ops = []
        for op in expr.operands:
            value = self.eval(op)
            if isinstance(value, Error):
                return value
            ops.append(value)

        if expr.op == 'not':
            return 1 if ops[0] == 0 else 0

        if expr.op == '+u':
            return ops[0]

        if expr.op == '-u':
            return -ops[0]

        if expr.op == '+':
            return ops[0] + ops[1]

        if expr.op == '-':
            return ops[0] - ops[1]

        if expr.op == '*':
            return ops[0] * ops[1]

        if expr.op == '/':
            if ops[1] == 0:
                return Error("Division by zero.")

            return ops[0] // ops[1]

        if expr.op == '==':
            return 1 if ops[0] == ops[1] else 0

        if expr.op == '!=':
            return 1 if ops[0] != ops[1] else 0

        if expr.op == '<=':
            return 1 if ops[0] <= ops[1] else 0

        if expr.op == '>=':
            return 1 if ops[0] >= ops[1] else 0

        if expr.op == '<':
            return 1 if ops[0] < ops[1] else 0

        if expr.op == '>':
            return 1 if ops[0] > ops[1] else 0

        assert False  # unreachable


def shortcut(left: int | Error, op: str) -> bool:
    return isinstance(left, Error) or (
        left == 0 if op == 'and' else left != 0
    )


# --- Parser ---

# Note: We use strings to represent tokens.
# There are better options, but for the purpose of this simple example,
# strings are enough.
# To represent the special tokens (NL, INDENT, DEDENT, EOF) we use strings
# that never appear as tokens themselves.
NL = '\n'
INDENT = '\t'
DEDENT = '\b'
EOF = '\0'

# Nice representation of tokens for error messages.
TOKEN_REPR = {
    NL: "end of line",
    INDENT: "an indented block",
    DEDENT: "end of an indented block",
    EOF: "end of file",
}

# Reserved keywords that may not appear as identifiers.
KEYWORDS = {
    'and', 'or', 'not',
    'if', 'else', 'elif', 'while',
}

DOUBLE_CHAR_TOKENS = {'!=', '==', '<=', '>='}
SINGLE_CHAR_TOKENS = {'+', '-', '*', '/', '(', ')', '=', '<', '>', ':'}

# Operators, ordered by their precedence level, with corresponding arity.
# All non-relational binary operators are left-associative here.
# To keep things simple, relational operators are non-associative.
# (Python sequencing of the form a < b < c requires extra care
#  and a completely naive solution would parse this as (a < b) < c.)
# Unary ‹+› and ‹-› are treated specially (see below) and after parsing,
# they are represented by the pseudo-operators ‹+u› and ‹-u›.

OPS_BY_PREC = [
    (2, {'or'}),
    (2, {'and'}),
    (1, {'not'}),
    (2, {'==', '!=', '<=', '>=', '<', '>'}),
    (2, {'+', '-'}),  # binary ‹+› and ‹-›
    (2, {'*', '/'}),
    (1, {'+', '-'}),  # unary ‹+› and ‹-›, special-cased
]

NON_ASSOC_LEVELS = {3}  # relational operators only


class Parser:
    def __init__(self, filename: str):
        lexer = Lexer(filename)
        self.error = lexer.error
        self.lines = lexer.lines
        self.line_no = 1  # This also works as the next index to ‹self.lines›.
        self.tokens = self.lines[0]
        self.index = 0
        self.fix_eol()  # Deal with inputs that start with an empty line.

    def set_error(self, msg: str) -> None:
        self.error = Error(msg)
        self.error.line_no = self.line_no

    def set_error_expecting(self, expected: str) -> None:
        # We can only find an unexpected DEDENT token if we expected
        # an «increased» indentation level.
        explanation = "" if self.peek() == DEDENT \
            else ", found " + token_repr(self.peek())

        self.set_error("Expected " + expected + explanation + ".")

    def peek(self) -> str:
        return self.tokens[self.index]

    def consume(self) -> None:
        self.index += 1
        self.fix_eol()

    def fix_eol(self) -> None:
        # We check the end-of-line condition in a cycle instead of an ‹if› so
        # we skip over empty lines if possible.
        while self.index == len(self.tokens):
            self.tokens = self.lines[self.line_no]
            self.line_no += 1
            self.index = 0

    def next(self) -> str:
        token = self.peek()
        self.consume()
        return token

    def accept(self, token: str) -> bool:
        if self.peek() != token:
            return False
        self.consume()
        return True

    def expect(self, token: str) -> bool:
        if self.accept(token):
            return True
        self.set_error_expecting(token_repr(token))
        return False

    def expect_seq(self, tokens: list[str]) -> bool:
        for token in tokens:
            if not self.expect(token):
                return False
        return True

    def try_ident(self) -> str | None:
        if is_ident(self.peek()):
            return self.next()
        return None

    def parse(self) -> Program | Error:
        if self.error is not None:
            return self.error  # Propagate lexer error.

        program = []
        while self.peek() != EOF:
            asgn = self.statement()
            if asgn is None:
                assert self.error is not None
                return self.error
            program.append(asgn)

        return program

    def statement_block(self) -> Block | None:
        block = []
        if not self.expect(INDENT):
            return None

        while not self.accept(DEDENT):
            stmt = self.statement()
            if stmt is None:
                return None
            block.append(stmt)
        return block

    def statement(self) -> Statement | None:
        if self.accept('if'):
            return self.if_stmt()

        if self.accept('while'):
            return self.while_stmt()

        return self.assignment()

    def branch_with_cond(self) -> tuple[Expression, Block] | None:
        cond = self.expression(0)
        if cond is None:
            return None

        if not self.expect_seq([':', NL]):
            return None

        block = self.statement_block()
        if block is None:
            return None

        return cond, block

    def while_stmt(self) -> While | None:
        bwc = self.branch_with_cond()
        if bwc is None:
            return None
        cond, body = bwc
        return While(cond, body)

    def if_stmt(self) -> If | None:
        bwc = self.branch_with_cond()
        if bwc is None:
            return None
        cond, body = bwc

        main_if = last_if = If(cond, body)

        while self.accept('elif'):
            bwc = self.branch_with_cond()
            if bwc is None:
                return None
            cond, body = bwc

            new_if = If(cond, body)
            last_if.else_body = [new_if]
            last_if = new_if

        if self.accept('else'):
            if not self.expect_seq([':', NL]):
                return None

            block = self.statement_block()
            if block is None:
                return None

            last_if.else_body = block

        return main_if

    def assignment(self) -> Assignment | None:
        var = self.try_ident()
        if var is None:
            self.set_error_expecting('identifier')
            return None

        if not self.expect('='):
            return None

        expr = self.expression(0)
        if expr is None:
            return None

        if not self.expect(NL):
            return None

        return Assignment(var, expr)

    def expression(self, level: int) -> Expression | None:
        if level == len(OPS_BY_PREC):
            return self.simple_expr()

        arity, ops = OPS_BY_PREC[level]
        non_assoc = level in NON_ASSOC_LEVELS

        if arity == 1:
            if self.peek() not in ops:
                return self.expression(level + 1)

            op = self.next()
            if op in ['+', '-']:  # special case for unary ‹+› and ‹-›
                op += 'u'
            expr = self.expression(level)
            if expr is None:
                return None

            return Op(op, [expr])

        # binary ops
        current = self.expression(level + 1)
        if current is None:
            return None

        first = True

        while self.peek() in ops:
            if non_assoc and not first:
                self.set_error("Relational operators are non-associative.")
                return None

            first = False

            op = self.next()
            right = self.expression(level + 1)
            if right is None:
                return None

            current = Op(op, [current, right])

        return current

    def simple_expr(self) -> Expression | None:
        if self.accept('('):
            expr = self.expression(0)
            if expr is None or not self.expect(')'):
                return None

            return expr

        var = self.try_ident()
        if var is not None:
            return var

        num = to_int(self.peek())
        if num is not None:
            self.consume()
            return num

        self.set_error_expecting("expression")
        return None


# --- Lexer ---

# A lexer reads the input file and produces tokens for the parser.
# To remember line numbers, we put the tokens in several lists, one per line.
class Lexer:
    def __init__(self, filename: str):
        self.lines: list[list[str]] = []
        self.error: Error | None = None
        self.indent = [0]

        with open(filename) as f:
            for line in f:
                self.process_line(line)
                if self.error is not None:
                    break

        self.lines.append([DEDENT for _ in range(len(self.indent) - 1)]
                          + [EOF])

    def set_error(self, msg: str) -> None:
        assert self.error is None
        self.error = Error(msg)
        self.error.line_no = len(self.lines)

    def process_line(self, line: str) -> None:
        if line[-1] != '\n':
            # Add newline at the end of non-POSIX compliant text files.
            # This makes the rest of the code slightly simpler.
            line += '\n'

        tokens: list[str] = []
        self.lines.append(tokens)
        pos = 0
        token = ''

        while line[pos] == ' ':
            pos += 1

        if line[pos] in ['#', '\n']:
            # Empty line: No tokens here, just add an empty list to ‹lines›.
            return

        if not self.process_indent(pos, tokens):
            return

        while token != NL:
            nt = self.next_token(line, pos)
            if nt is None:
                return
            token, pos = nt
            tokens.append(token)

    def process_indent(self, pos: int, tokens: list[str]) -> bool:
        # This method produces the virtual INDENT and DEDENT tokens.
        # An INDENT token represents an increase in the indentation level
        # (and thus the beginning of a block of code),
        # while a DEDENT token represents a decrease (the end of a block).
        if pos > self.indent[-1]:
            self.indent.append(pos)
            tokens.append(INDENT)
            return True

        while pos < self.indent[-1]:
            self.indent.pop()
            tokens.append(DEDENT)

        if pos != self.indent[-1]:
            self.set_error("Invalid indentation.")
            return False

        return True

    def next_token(self, line: str, pos: int) -> tuple[str, int] | None:
        token = ""

        # ignore spaces
        while line[pos] == " ":
            pos += 1

        if line[pos] in ['#', '\n']:
            return NL, pos

        if line[pos] + line[pos + 1] in DOUBLE_CHAR_TOKENS:
            return line[pos] + line[pos + 1], pos + 2

        if line[pos] in SINGLE_CHAR_TOKENS:
            return line[pos], pos + 1

        if line[pos].isdecimal():
            # reading a number
            while line[pos].isdecimal():
                token += line[pos]
                pos += 1
            return token, pos

        if is_ident_start(line[pos]):
            while is_ident_inside(line[pos]):
                token += line[pos]
                pos += 1
            return token, pos

        self.set_error("Invalid character ‹" + line[pos] + "› in column "
                       + to_str(pos + 1) + ".")
        return None


def token_repr(token: str) -> str:
    return TOKEN_REPR.get(token, "‹" + token + "›")


def is_ident(token: str) -> bool:
    return is_ident_start(token[0]) and token not in KEYWORDS


def is_ident_start(char: str) -> bool:
    return char.isalpha() or char == '_'


def is_ident_inside(char: str) -> bool:
    return is_ident_start(char) or char.isdecimal()


# --- AST Graph ---

class ASTGraph:
    def __init__(self, program: Program) -> None:
        self.nodes: list[str] = []
        self.edges: list[tuple[int, int]] = []
        prog = self.add_node('Program')
        for statement in program:
            self.add_edge(prog, self.add_stmt(statement))

    def add_node(self, label: str) -> int:
        self.nodes.append(label)
        return len(self.nodes) - 1

    def add_edge(self, src: int, dst: int) -> None:
        self.edges.append((src, dst))

    def add_expr(self, expr: Expression) -> int:
        if isinstance(expr, int):
            return self.add_node(to_str(expr))

        if isinstance(expr, str):
            return self.add_node(expr)

        this = self.add_node(expr.op)
        for operand in expr.operands:
            self.add_edge(this, self.add_expr(operand))

        return this

    def add_stmt(self, statement: Statement) -> int:
        if isinstance(statement, If):
            return self.add_if(statement)

        if isinstance(statement, While):
            return self.add_while(statement)

        # Assignment
        this = self.add_node('=')
        self.add_edge(this, self.add_node(statement.var))
        self.add_edge(this, self.add_expr(statement.expr))
        return this

    def add_if(self, if_stmt: If) -> int:
        this = self.add_node("if")

        self.add_edge(this, self.add_expr(if_stmt.cond))
        self.add_edge(this, self.add_block(if_stmt.main_body, "main\\nbody"))

        if if_stmt.else_body is not None:
            self.add_edge(this, self.add_block(if_stmt.else_body, "else"))

        return this

    def add_while(self, while_stmt: While) -> int:
        this = self.add_node("while")
        self.add_edge(this, self.add_expr(while_stmt.cond))
        self.add_edge(this, self.add_block(while_stmt.body, "body"))
        return this

    def add_block(self, block: Block, label: str) -> int:
        this = self.add_node(label)

        for statement in block:
            self.add_edge(this, self.add_stmt(statement))

        return this

    def draw(self, filename: str) -> None:
        with open(filename, 'w') as dot_file:
            dot_file.write("digraph {\n")

            for i, node in enumerate(self.nodes):
                dot_file.write('n' + to_str(i) + ' [label="' + node + '"]\n')

            for src, dst in self.edges:
                dot_file.write('n' + to_str(src) +
                               ' -> n' + to_str(dst) + '\n')

            dot_file.write("}\n")


# --- Conversion Functions ---

DIGITS = list("0123456789")


def to_int(digits: str) -> int | None:
    result = 0
    for digit in digits:
        if digit not in DIGITS:
            return None
        result = result * 10 + DIGITS.index(digit)
    return result


def to_str(num: int) -> str:
    if num == 0:
        return "0"
    if num < 0:
        return '-' + to_str(-num)

    result = ""
    while num > 0:
        result = DIGITS[num % 10] + result
        num //= 10
    return result


# --- Main Functions ---

def draw(program: Program, filename: str) -> None:
    ASTGraph(program).draw(filename)


def parse(filename: str) -> Program | Error:
    return Parser(filename).parse()


# Note: The function ‹run› is pure.

def run(program: Program) -> dict[str, int] | Error:
    return Interpreter(program).run()


def print_error(err: Error) -> None:
    kind = "Runtime error: " if err.line_no == 0 \
        else "Syntax error on line " + to_str(err.line_no) + ": "
    sys.stderr.write(kind + err.msg + "\n")


def main() -> None:
    if len(sys.argv) != 2 and (len(sys.argv) != 3 or sys.argv[1] != '-d'):
        sys.stdout.write(
            "Usage: " + sys.argv[0] + " [-d] filename\n"
            "    with -d draws the AST in GraphViz format to ast.dot\n"
        )
        return

    program = parse(sys.argv[-1])
    if isinstance(program, Error):
        print_error(program)
        return

    if sys.argv[1] == '-d':
        draw(program, "ast.dot")
        return

    env = run(program)
    if isinstance(env, Error):
        print_error(env)
        return

    sys.stdout.write("Variable values:\n")
    for name, value in env.items():
        sys.stdout.write("  " + name + " = " + to_str(value) + "\n")


if __name__ == '__main__':
    main()
